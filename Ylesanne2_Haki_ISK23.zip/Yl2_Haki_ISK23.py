import pygame # impordime pygame mooduli
import sys    # impordime süsteemimooduli

# Initsialiseerime Pygame'i
pygame.init()

# Akna suurus ja loomine
screen_size = (640, 480)   # määrame tehtava akna suuruse - 640 x 480 pixlit
screen = pygame.display.set_mode(screen_size)   # loome Pygame mooduli abil akna, millele on eelnevalt määratud ka suurus 
pygame.display.set_caption("2")   # määrame Pygame aknale nimeks "2" (Juhend: Lisa mängu nimeks ülesande number)

# Pildid ja nende suuruste muutmine (kui vaja)
background_image = pygame.image.load("bg_shop.png")  # taustapilt bg_shop.jpg
seller = pygame.image.load("seller.png")  # seller ehk müüja, ehk mingi tüüp keset shop'i
seller = pygame.transform.scale(seller, (260, 307))  # kuna seller on originaalis väga suur, siis tuleb tema parameetreid tuunida

chat_bubble = pygame.image.load("chat.png")  # chat_bubble ehk jutumull/kast
chat_bubble = pygame.transform.scale(chat_bubble, (256,203))  # kuna ka see pilt on liialt suur ekraani jaoks, siis tuleb ka tema parameetreid muuta

# Nüüd sätime muudetud mõõtudega pildid enam-vähem õigesse kohta
seller_position = (103, 157)  # enam-vähem õige asukoht seller'ile
chat_bubble_position = (246, 65) # enam-vähem õige asukoht jutukastile

# Määrame font'i jutukasti sees olevale tekstile, selle suuruse ja teeme ka rasvaseks
font = pygame.font.SysFont("comicsansms", 18, bold=True)  # kasutame süsteemifonti, peaks tõenäoliselt igas masinas toimima

# Määrame, mis teksti me selle font'iga kirjutame
text = "Tere, olen Jaanika Haki"

# Mängutsükkel
running = True  # muutuja running loomine
while running:  # algab lõpmatu tsükkel, mis kestab kuni running = True
    for event in pygame.event.get():  # tsükkel mis käib läbi kõik kasutaja poolsed sündmused (nt akna sulgemise)
        if event.type == pygame.QUIT:  # kui kasutaja sulgeb Pygame abil loodud akna...
            running = False  # siis Pygame katkestab akna tsükli

    # Joonistame taustapildi aknale
    screen.blit(background_image, (0, 0))  # blit ehk block transfer ehk joonistame taustapildi (bg_shop) akna taustale, "0,0" määrab et bg_shop.png asuks täpselt aknas

    # Paneme seller'i akna vasakule poolele
    screen.blit(seller, seller_position) #seller'i pilt ja positsioon (eelnevalt määratud)

    # Paneme jutukasti enam-vähem üles paremale poole
    screen.blit(chat_bubble, chat_bubble_position)  #jutukast ja selle positsioon (eelnevalt määratud)

    # Joonistame jutukastile teksti
    text_surface = font.render(text, True, (255, 255, 255))  # eelnevalt määratud text, valge tekst
    text_rect = text_surface.get_rect(center=(chat_bubble_position[0] + chat_bubble.get_width() // 2,
                                              chat_bubble_position[1] + chat_bubble.get_height() // 2.5))
    screen.blit(text_surface, text_rect)

    # Ekraani värskendamine, tagab sujuva töö
    pygame.display.flip()

# Mängu lõpp (kui kasutaja on akna sulgenud) ja ressurside kasutamise lõpetamine
pygame.quit()
sys.exit()
